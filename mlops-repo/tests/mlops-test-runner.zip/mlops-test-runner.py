import boto3
import json
import os
import urllib3

cpipe = boto3.client('codepipeline')
def handler(event, context):
    
    payload = {
        "features":"0,106,0,274.4,120,198.6,82,160.8,62,6.0,3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,1"
    }

    method = 'POST'
    headers = {}
    body = payload
    url = os.environ['app_ep']
    http = urllib3.PoolManager()
    
    job_id = event['CodePipeline.job']['id']
    
    try:
        response = http.request('POST', url, body=json.dumps(payload))
        
        if response.status == 200 :
            predictions = response.data.decode('utf-8')
            cpipe.put_job_success_result(jobId=job_id, outputVariables= json.loads(predictions))
        else :
            msg = "Failed to communicate with endpoint. Response was {}.".format(response)
            cpipe.put_job_failure_result(jobId=job_id, 
                                        failureDetails={"type":"JobFailed","message":msg})
        
    except Exception as e :
        cpipe.put_job_failure_result(jobId=job_id, failureDetails={"type":"JobFailed","message":"Test failed. Exception: {}".format(e)})

    return {"prediction": prediction}